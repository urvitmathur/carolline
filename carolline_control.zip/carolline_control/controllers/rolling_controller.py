"""
Rolling controller (CAROLLINE paper, Sec. III-C).

Holonomic rolling on a flat floor without reorienting the cage:

    v = omega x [0, 0, R]

Velocity is commanded in world XY; torque acts about world horizontal axes
only (no deliberate yaw spin). Reversing direction reverses roll rate.
"""

from __future__ import annotations

import numpy as np

from carolline_control.utils.so3 import body_z_world, rolling_omega_world
from carolline_control.utils.types import ControlCommand, ControllerConfig, ControlMode, RobotState


class RollingController:
    """Holonomic ground locomotion controller."""

    MAX_ROLL_MOMENT = 7.0

    def __init__(self, config: ControllerConfig) -> None:
        self._config = config
        self._v_int = np.zeros(2)

    def reset(self) -> None:
        self._v_int[:] = 0.0

    def compute(
        self,
        state: RobotState,
        desired_velocity_xy: np.ndarray,
        yaw: float,
        dt: float,
        yaw_rate: float = 0.0,
    ) -> ControlCommand:
        """Compute rolling control command."""
        _ = yaw, yaw_rate
        v_des = np.clip(
            desired_velocity_xy,
            -self._config.rolling_max_speed,
            self._config.rolling_max_speed,
        )
        v_err = v_des - state.velocity[:2]
        self._v_int += v_err * max(dt, 1e-6)
        self._v_int = np.clip(self._v_int, -1.2, 1.2)

        v_track = v_des + 0.35 * self._v_int
        R = self._config.cage_radius
        r_cp = np.array([0.0, 0.0, R], dtype=float)
        v_world = np.array([v_track[0], v_track[1], 0.0], dtype=float)
        omega_world = rolling_omega_world(v_world, r_cp, yaw_rate=0.0)
        omega_body = state.rotation.T @ omega_world

        mass = self._config.mass
        kp_f = self._config.rolling_kp * mass * 4.0
        kd_f = self._config.rolling_kd * mass * 1.0
        f_xy = kp_f * v_err - kd_f * state.velocity[:2]
        f_world = np.array([f_xy[0], f_xy[1], 0.0], dtype=float)
        moment_world = np.cross(r_cp, f_world)
        moment_world[2] = 0.0
        moment_body = state.rotation.T @ moment_world
        moment_body[2] *= 0.15
        speed_act = float(np.linalg.norm(state.velocity[:2]))
        moment_scale = float(np.clip(0.35 + speed_act / 0.15, 0.35, 1.0))
        moment_body *= moment_scale
        m_norm = float(np.linalg.norm(moment_body))
        if m_norm > self.MAX_ROLL_MOMENT:
            moment_body *= self.MAX_ROLL_MOMENT / m_norm

        weight = mass * self._config.gravity
        b3_z = max(float(body_z_world(state.rotation)[2]), 0.15)
        thrust = self._config.pre_takeoff_thrust_fraction * weight * (0.32 + 0.38 * b3_z)

        return ControlCommand(
            thrust=thrust,
            moment_body=moment_body,
            desired_omega_body=omega_body,
            desired_rotation=state.rotation.copy(),
            mode=ControlMode.ROLLING,
        )

    @staticmethod
    def planar_velocity_from_state(state: RobotState) -> np.ndarray:
        """Estimate current planar velocity from rigid-body kinematics."""
        return state.velocity[:2]
