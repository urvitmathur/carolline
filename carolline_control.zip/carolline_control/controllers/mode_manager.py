"""
Mode manager — finite state machine for CAROLLINE operating modes.

States: PRETAKEOFF, UPRIGHT, TAKEOFF, HOVER, FLIGHT, ROLLING, LANDING, IDLE

Transitions follow the CAROLLINE paper modular architecture (Sec. III).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from carolline_control.utils.so3 import body_z_world
from carolline_control.utils.types import ControlMode, ControllerConfig, RobotState


@dataclass
class ModeManager:
    """Automatic mode switching logic."""

    config: ControllerConfig
    mode: ControlMode = field(default=ControlMode.PRETAKEOFF)
    mission_phase: int = 0
    hover_timer: float = 0.0
    landing_timer: float = 0.0
    rolling_timer: float = 0.0
    upright_timer: float = 0.0
    pre_upright_timer: float = 0.0
    request_rolling: bool = False

    def __post_init__(self) -> None:
        self.mode = self.config.initial_mode

    def update(self, state: RobotState, dt: float, mission_complete: bool = False) -> ControlMode:
        """Evaluate transition rules and return active mode."""
        if self.mode == ControlMode.ROLLING:
            pos_err = state.position[:2] - self.config.roll_target
            at_goal = (
                state.on_ground
                and float(np.linalg.norm(pos_err)) < self.config.roll_position_tolerance
                and float(np.linalg.norm(state.velocity[:2])) < 0.08
            )
            if at_goal:
                self.rolling_timer += dt
                if self.rolling_timer >= 0.5:
                    self.mode = ControlMode.PRETAKEOFF
                    self.rolling_timer = 0.0
            else:
                self.rolling_timer = 0.0
            if not state.on_ground:
                self.mode = ControlMode.HOVER

        elif self.mode == ControlMode.PRETAKEOFF:
            bz = float(body_z_world(state.rotation)[2])
            omega_ok = float(np.linalg.norm(state.omega_body)) < self.config.upright_omega_tolerance
            if bz >= self.config.upright_cos_threshold and omega_ok:
                self.pre_upright_timer += dt
                if self.pre_upright_timer >= 0.4:
                    self.mode = ControlMode.UPRIGHT
                    self.upright_timer = 0.0
            else:
                self.pre_upright_timer = 0.0

        elif self.mode == ControlMode.UPRIGHT:
            bz = float(body_z_world(state.rotation)[2])
            omega_ok = float(np.linalg.norm(state.omega_body)) < self.config.upright_omega_tolerance
            if self.request_rolling:
                self.mode = ControlMode.ROLLING
                self.request_rolling = False
                self.upright_timer = 0.0
            elif (
                state.on_ground
                and bz >= self.config.takeoff_cos_threshold
                and omega_ok
            ):
                self.upright_timer += dt
                if self.upright_timer >= self.config.upright_settle_time:
                    self.mode = ControlMode.TAKEOFF
                    self.upright_timer = 0.0
            else:
                self.upright_timer = 0.0

        elif self.mode == ControlMode.TAKEOFF:
            bz = float(body_z_world(state.rotation)[2])
            alt_err = abs(state.position[2] - self.config.hover_height)
            alt_ok = alt_err < self.config.hover_altitude_tolerance
            upright = bz >= self.config.takeoff_cos_threshold
            vel_ok = float(np.linalg.norm(state.velocity)) < self.config.hover_velocity_tolerance
            if alt_ok and upright and vel_ok:
                self.mode = ControlMode.HOVER
                self.hover_timer = 0.0

        elif self.mode == ControlMode.HOVER:
            self.hover_timer += dt
            bz = float(body_z_world(state.rotation)[2])
            alt_err = abs(state.position[2] - self.config.hover_height)
            alt_ok = alt_err < self.config.hover_altitude_tolerance
            vel_ok = float(np.linalg.norm(state.velocity)) < self.config.hover_velocity_tolerance
            upright = bz >= self.config.upright_cos_threshold
            if self.hover_timer > 3.0 and alt_ok and vel_ok and upright:
                self.mode = ControlMode.FLIGHT

        elif self.mode == ControlMode.FLIGHT:
            if mission_complete:
                self.mode = ControlMode.LANDING
                self.landing_timer = 0.0

        elif self.mode == ControlMode.LANDING:
            bz = body_z_world(state.rotation)[2]
            if state.on_ground and bz < self.config.upright_cos_threshold:
                self.mode = ControlMode.PRETAKEOFF
                self.landing_timer = 0.0
            elif state.on_ground and bz >= self.config.upright_cos_threshold:
                settled = (
                    np.linalg.norm(state.velocity) < 0.05
                    and abs(state.position[2] - state.ground_contact_z) < 0.05
                )
                if settled:
                    self.landing_timer += dt
                    if self.landing_timer >= self.config.landing_settle_time:
                        self.mode = ControlMode.IDLE
                else:
                    self.landing_timer = 0.0

        return self.mode

    def set_mission_phase(self, phase: int) -> None:
        self.mission_phase = phase
