"""
Pre-takeoff controller (CAROLLINE paper, Sec. III-B).

The robot starts in an arbitrary orientation on the cage. This controller:
1. Detects orientation via R (no Euler angles)
2. Computes SO(3) error to upright pre-takeoff pose
3. Commands angular velocity to roll on the cage using contact
4. Applies low collective thrust to assist righting without liftoff
"""

from __future__ import annotations

import numpy as np

from carolline_control.controllers.orientation_generator import OrientationGenerator
from carolline_control.utils.so3 import body_z_world
from carolline_control.utils.types import ControlCommand, ControllerConfig, ControlMode, RobotState


class PreTakeoffController:
    """Ground recovery controller before takeoff."""

    def __init__(self, config: ControllerConfig) -> None:
        self._config = config
        self._orientation = OrientationGenerator()

    def compute(self, state: RobotState, mode: ControlMode = ControlMode.PRETAKEOFF) -> ControlCommand:
        """Generate pre-takeoff wrench command."""
        Rd = self._orientation.pre_takeoff(state)

        b3_z = float(body_z_world(state.rotation)[2])
        weight = self._config.mass * self._config.gravity
        if mode == ControlMode.UPRIGHT:
            # Hold low thrust while attitude settles on the ground before takeoff.
            thrust = self._config.pre_takeoff_thrust_fraction * weight * float(
                np.clip(0.25 + 0.35 * max(b3_z, 0.0), 0.15, 0.45)
            )
        elif b3_z >= 0.0:
            thrust = self._config.pre_takeoff_thrust_fraction * weight * max(b3_z, 0.05)
        else:
            # Inverted on cage: apply modest thrust to assist roll-over.
            thrust = self._config.pre_takeoff_thrust_fraction * weight * 0.35

        return ControlCommand(
            thrust=thrust,
            moment_body=np.zeros(3),
            desired_omega_body=np.zeros(3),
            desired_rotation=Rd,
            mode=mode,
        )

    @staticmethod
    def is_upright(state: RobotState, cos_threshold: float) -> bool:
        """Check if body z-axis is aligned with world up."""
        return float(body_z_world(state.rotation)[2]) >= cos_threshold
