"""
State estimation from MuJoCo sensors and kinematics.

Step 1 of the CAROLLINE architecture: reads position, quaternion,
linear/angular velocity and constructs R, body/world vectors.
No Euler angles are used internally.
"""

from __future__ import annotations

import mujoco
import numpy as np

from carolline_control.utils.so3 import quat_to_rot
from carolline_control.utils.types import ControllerConfig, RobotState


class StateEstimator:
    """Simulator-backed state estimator."""

    def __init__(self, model: mujoco.MjModel, config: ControllerConfig) -> None:
        self._model = model
        self._config = config
        self._body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "x2")
        self._site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "imu")

        self._sensor_quat = self._sensor_adr("body_quat", 4)
        self._sensor_gyro = self._sensor_adr("body_gyro", 3)
        self._sensor_acc = self._sensor_adr("body_linacc", 3)
        self._sensor_linvel = self._try_sensor_adr("body_vel", 3)
        self._sensor_angvel = self._try_sensor_adr("body_angvel", 3)

    def _sensor_adr(self, name: str, size: int) -> slice:
        adr = mujoco.mj_name2id(self._model, mujoco.mjtObj.mjOBJ_SENSOR, name)
        if adr < 0:
            raise ValueError(f"Required sensor '{name}' not found in MJCF model.")
        start = self._model.sensor_adr[adr]
        return slice(start, start + size)

    def _try_sensor_adr(self, name: str, size: int) -> slice | None:
        adr = mujoco.mj_name2id(self._model, mujoco.mjtObj.mjOBJ_SENSOR, name)
        if adr < 0:
            return None
        start = self._model.sensor_adr[adr]
        return slice(start, start + size)

    def estimate(self, data: mujoco.MjData) -> RobotState:
        """Build RobotState from MuJoCo data buffers."""
        position = data.qpos[:3].copy()
        quaternion = data.qpos[3:7].copy()
        rotation = quat_to_rot(quaternion)

        if self._sensor_linvel is not None:
            velocity = data.sensordata[self._sensor_linvel].copy()
        else:
            velocity = data.qvel[:3].copy()

        if self._sensor_angvel is not None:
            omega_world = data.sensordata[self._sensor_angvel].copy()
        else:
            omega_world = data.qvel[3:6].copy()
        omega_body = rotation.T @ omega_world

        accel_body = data.sensordata[self._sensor_acc].copy()
        on_ground = position[2] <= self._config.ground_height_threshold
        ground_contact_z = self._config.cage_radius

        return RobotState(
            position=position,
            velocity=velocity,
            quaternion=quaternion,
            rotation=rotation,
            omega_body=omega_body,
            omega_world=omega_world,
            accel_body=accel_body,
            on_ground=on_ground,
            ground_contact_z=ground_contact_z,
            time=float(data.time),
        )

    def fill_inertial_params(self, config: ControllerConfig) -> None:
        """Read mass and inertia from MuJoCo once the model is loaded."""
        mass = float(self._model.body_subtreemass[self._body_id])
        if mass <= 0.0:
            mass = float(np.sum(self._model.body_mass))
        config.mass = mass

        inertia = np.diag(self._model.body_inertia[self._body_id].copy())
        if np.allclose(inertia, 0.0):
            inertia = np.diag([0.043, 0.043, 0.043])
        config.inertia = inertia
